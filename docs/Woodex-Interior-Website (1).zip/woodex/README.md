# Woodex Interior — master website theme

A complete, responsive static website, closely following the visual language of the supplied Linoxa Home Two reference, adapted for an interior studio. This is a newly coded HTML/CSS/JavaScript implementation, not an exported or licensed copy of the Webflow template.

## Start here

Open `index.html` in your browser, or upload the HTML pages and the `assets` folder to any static web host. No Node.js, database, build step, CDN, or external image/font requests are required.

For a local server:

```bash
python -m http.server 3000
```

Then visit `http://localhost:3000`.

## Included pages (18)

- Home: `index.html`
- About: `about.html`
- Services: `services.html` — six service sections and FAQs
- Portfolio: `portfolio.html` — All, Residential, Commercial, and Bespoke filters
- Six project detail pages: `project-*.html`
- Insights: `insights.html`
- Three complete articles: `insight-*.html`
- Contact: `contact.html`
- Master style guide: `style-guide.html`
- Starter privacy information: `privacy.html`
- Not-found design: `404.html` (configure your hosting provider to serve it for missing pages)

## Master theme

Edit the CSS variables at the top of `assets/theme.css` to update all pages:

| Token | Purpose |
| --- | --- |
| `--ink` | Main text and dark buttons |
| `--navy` | Dark blue feature sections |
| `--paper`, `--soft`, `--beige` | Background palette |
| `--heading`, `--font` | Heading and body font stacks |
| `--gutter` | Responsive page padding |
| `--section` | Responsive vertical spacing |
| `--radius` | Image and panel corner radius |

The reference font pairing is **Nohemi** headings and **Inter** body copy. Both are bundled locally. See `THIRD-PARTY.md` and the Inter license in `assets`.

The theme includes reusable headers, footers, buttons, photographic heroes, service cards, project cards, process grids, article cards, accordions, forms, and inner-page patterns. `style-guide.html` shows the main components in context.

## Editing content

Two approaches are supported:

1. **Direct editing:** edit the generated HTML files with a text editor. Each page has its own fully rendered HTML and remains readable without JavaScript.
2. **Shared-source editing (recommended):** edit `generate.py`, then run `python generate.py`. Shared navigation, footer, project content, articles, and page structures are defined there. This requires only Python's standard library.

**Important:** regeneration overwrites the HTML files. Do not mix direct HTML edits and generator edits without copying your changes back into the generator. CSS and JavaScript are not overwritten.

Replace images in `assets`, or change their filenames in `generate.py`. Use landscape images at least 1400px wide for banners and large cards. Update the corresponding alt text. The supplied wordmark is editable inline SVG/text in the `LOGO` variable. Edit `assets/favicon.svg` separately.

Hero slide text is defined in `assets/site.js`; the initial slide also exists in `generate.py` for fast loading and no-JavaScript support. Update both when changing the first slide. Hero images are defined in the homepage markup.

## Contact form: demo mode vs. live mode

### Included demo mode

The form uses browser validation and prepares a downloadable text enquiry brief. **It does not send email, submit data, or store information on a server.** The button is disabled when JavaScript is unavailable. No success message falsely claims delivery.

Service-page enquiry buttons preselect the relevant service on the contact form.

### Enable real submissions

1. Create a form with a hosted provider such as Formspree, or implement your own endpoint.
2. Open `assets/site.js` and set:

```js
const WOODEX = { formEndpoint: 'https://formspree.io/f/YOUR_ACTUAL_FORM_ID' };
```

3. The handler must accept multipart form data via POST and return a successful HTTP status only when the enquiry is accepted. The browser requests a JSON response. For another domain, configure CORS appropriately.
4. On a hosted HTTPS site, test a real submission, check the receiving inbox, and verify error behavior. A live provider integration has not been configured or tested with a real account in this delivery.
5. Replace the starter privacy page with your actual policy and confirm your provider's spam controls and retention settings. Do not put private API keys in frontend JavaScript.

The labels switch to a live-enquiry message when an endpoint is configured. During a failed submission, the form retains entered details and explains that the enquiry could not be sent.

## Before publishing

- Replace all bracketed address, email, telephone, studio hours, and privacy placeholders.
- Review the studio positioning and service descriptions against your actual business.
- Replace the **sample concept portfolio** with real project descriptions and cleared photography. Supplied projects are explicitly labeled as concepts, not completed Woodex work. Gallery photographs can show different properties.
- Check image/font terms for your use and retain third-party notices. No ownership of stock photos or fonts is implied.
- Configure and test the enquiry endpoint, then finalize your privacy information.
- Confirm ownership/availability of the Woodex name and the provisional wordmark before brand launch.
- Add your final domain's canonical URLs, social-sharing image, sitemap, and robots.txt as appropriate. Titles and descriptions are already included; no guessed business address or fake review structured data is embedded.
- Enable HTTPS, caching, compression, and your host's custom 404 configuration.
- Remove development files from your hosting upload if desired: `generate.py`, this README, and review/test documents are not runtime dependencies. Keep applicable asset license notices.

## Interaction and accessibility features

- Real HTML page links; no framework or client-side routing required in the deployable website.
- Manual three-slide hero, with accessible labels and slide announcements.
- Mobile menu with Escape-to-close and expanded state.
- Portfolio filtering with visible result count.
- Native keyboard-operable disclosure/FAQ components.
- Labeled inputs, native validation, download-only demo form, live status messages.
- Skip link, visible keyboard focus, meaningful image alternatives, and reduced-motion support.
- No cookies, analytics, external scripts, or local storage in the default theme.

## Checks performed

All 18 pages were checked in Chromium at 320px, 390px, 768px, and 1440px widths for horizontal overflow and a single main H1. Carousel controls, portfolio filters, mobile navigation/Escape, service prefilling, and the demo enquiry download were exercised. Internal links, asset paths, and local anchors were checked. These checks are not a formal accessibility audit or a cross-browser certification.

## Offline review file

The separately supplied `Woodex-Preview.html` embeds the pages, fonts, and photos in one file so the design can be reviewed in a network-isolated viewer. Its internal navigation is adapted for single-file viewing. **Use the `woodex` folder for deployment and editing**, rather than treating that review file as the production source.
