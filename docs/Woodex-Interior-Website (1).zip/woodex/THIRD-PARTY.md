# Design reference and third-party assets

## Visual reference

https://linoxa.webflow.io/home-two

The supplied reference informed the font pairing, image-led layout, display typography, grid lines, monochrome/navy palette, pill-shaped arrow buttons, and section styling. The website code, Woodex wordmark, icons, and starter copy were newly created for this project. No Webflow runtime, template source code, vendor branding, or template license is bundled or claimed.

## Nohemi

- Designer: Rajesh Rajput.
- Heading weights used: Regular, Medium, SemiBold.
- Font information: https://befonts.com/nohemi-font-family.html
- Designer distribution: https://rajputrajesh-448.gumroad.com/l/NOHEMI9
- The BeFonts listing states that Nohemi is available for personal and commercial projects, free or pay-what-you-want. Refer to the designer's current terms for your intended use.
- The bundled font files were obtained from the public font URLs used by the supplied reference. Do not treat the font as your own design or sell it as a standalone font product.

## Inter

- Designer: Rasmus Andersson and contributors.
- Source: https://github.com/rsms/inter
- Bundled variable font: https://raw.githubusercontent.com/rsms/inter/master/docs/font-files/InterVariable.woff2
- Licensed under the SIL Open Font License 1.1. Full notice: `assets/Inter-LICENSE.txt`.

## Photography

Photographs were downloaded from Unsplash image URLs, stored locally, and are used as illustrative stock imagery. Individual asset URLs are listed in `assets/photo-sources.txt`.

- License: https://unsplash.com/license
- Terms: https://unsplash.com/terms

These photographs are not Woodex client projects. Portfolio entries explicitly identify themselves as sample concepts. Some galleries combine different properties as visual inspiration. Replace these with your own cleared project photography before presenting a real client portfolio. Review any additional rights applicable to a specific photograph and intended use; this document is not a model, property, or trademark release.
